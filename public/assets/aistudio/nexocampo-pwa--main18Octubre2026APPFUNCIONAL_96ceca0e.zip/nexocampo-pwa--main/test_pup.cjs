const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', error => console.log('PAGE ERROR:', error.message));

  await page.goto('http://localhost:3000');
  
  await new Promise(r => setTimeout(r, 2000));
  console.log("Clicking Individual button...");
  await page.evaluate(() => {
    abrirRegistroIndividual();
  });
  
  await new Promise(r => setTimeout(r, 2000));
  await browser.close();
  console.log("Done");
})();
