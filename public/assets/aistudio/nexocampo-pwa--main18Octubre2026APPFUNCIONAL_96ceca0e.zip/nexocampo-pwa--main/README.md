# NexoCampo 🌱

**NexoCampo** es una Aplicación Web Progresiva (PWA) de alto rendimiento diseñada para la logística agrícola, la gestión de labores en el campo y el seguimiento del rendimiento de los colaboradores. Su principal fortaleza radica en su capacidad para operar completamente sin conexión a internet, asegurando que el trabajo de campo nunca se detenga.

## 🚀 Características Principales

- **📱 Instalable (PWA)**: Se instala como una aplicación nativa en dispositivos Android, iOS y Escritorio.
- **📶 100% Offline-First**: Diseñada para entornos rurales. Funciona perfectamente sin cobertura de red.
- **💾 Almacenamiento Local Robusto**: Los datos se guardan de forma segura en el dispositivo mediante IndexedDB.
- **📊 Gestión Integral**: Administración de colaboradores, áreas, labores, ausencias, asistencia y registros de jornadas (tanto individuales como grupales).
- **📅 Ausencias formalizadas**: Registro mediante los códigos I (Incapacidad), JV (Jurado de Votación), LP (Licencia de Paternidad), P (Permiso), V (Vacaciones), SP (Suspensión) y C (Compensado).
- **✅ Asistencia y consulta**: Registro de asistencia independiente del rendimiento y consulta cruzada por colaborador y fecha.
- **📈 Cálculo de Rendimiento**: Motor de cálculo preciso que evalúa el desempeño basándose en el tiempo productivo (descontando descansos, traslados y otros tiempos improductivos).
- **🔄 Sincronización y Respaldo**: Capacidad para exportar bases de datos completas a JSON, importar respaldos y generar reportes detallados (PDF/Impresión).

## 🛠️ Arquitectura Técnica

NexoCampo está construida priorizando la velocidad, la ligereza y la fiabilidad. No depende de frameworks pesados, lo que garantiza una carga instantánea y un bajo consumo de recursos.

- **Frontend Core**: **Vanilla JavaScript** (ES6+), HTML5 semántico.
- **Estilos**: Sistema de diseño basado en utilidades inspirado en **Tailwind CSS**, utilizando variables CSS nativas para un control de UI limpio y responsivo.
- **Persistencia de Datos**: **IndexedDB** a través de promesas asíncronas, garantizando un almacenamiento de datos estructurado superior al de `localStorage`.
- **PWA y Caché**: **Service Worker** dedicado para almacenar en caché de manera agresiva los recursos estáticos y permitir la carga de la aplicación sin red.

## 📁 Estructura de Archivos

```text
/
├── index.html            # Punto de entrada principal (Contiene la estructura HTML, estilos y lógica JS).
├── README.md             # Documentación del proyecto.
└── public/               # Recursos estáticos de la PWA
    ├── manifest.json     # Archivo de manifiesto web (configuración de instalación, colores, nombre).
    ├── sw.js             # Service Worker (gestión de caché y capacidades offline).
    ├── icon-192.svg      # Ícono vectorial optimizado (192x192) para la pantalla de inicio.
    └── icon-512.svg      # Ícono vectorial de alta resolución (512x512) para splash screens.
```

## 📲 Instrucciones de Instalación (PWA)

NexoCampo puede instalarse directamente desde el navegador, sin necesidad de pasar por tiendas de aplicaciones (App Store / Google Play).

### En Dispositivos Android (Vía Google Chrome)
1. Abre el enlace de la aplicación web en Chrome.
2. Toca el botón de **Menú (tres puntos)** en la esquina superior derecha del navegador.
3. Selecciona **"Añadir a la pantalla de inicio"** o **"Instalar aplicación"**.
4. Confirma la instalación. NexoCampo aparecerá en tu cajón de aplicaciones.

### En Dispositivos iOS / iPhone (Vía Safari)
1. Abre el enlace de la aplicación en el navegador Safari (obligatorio para iOS).
2. Toca el ícono de **"Compartir"** (el cuadrado con una flecha hacia arriba) en la barra de navegación inferior.
3. Desplázate hacia abajo y selecciona **"Añadir a la pantalla de inicio"**.
4. Confirma tocando "Añadir".

### En Computadoras de Escritorio (Windows / Mac / Linux)
1. Abre el enlace en Google Chrome o Microsoft Edge.
2. En la barra de direcciones (arriba, al extremo derecho), verás un **ícono de instalación** (usualmente una pantalla con una flecha hacia abajo).
3. Haz clic en el ícono y selecciona **"Instalar"**.
4. NexoCampo se abrirá en su propia ventana, funcionando como un programa de escritorio independiente.

---
*Desarrollado para optimizar el rendimiento y la logística en la agroindustria.*

### 💾 Organización de respaldos — Punto 6

NexoCampo permite organizar los respaldos tanto en Google Drive como en el almacenamiento local del dispositivo.

- **Google Drive:** los respaldos utilizan el alcance `drive.file` y se organizan mediante una carpeta visible de NexoCampo. La aplicación reutiliza la carpeta y el archivo de respaldo existentes cuando están disponibles, evitando duplicados innecesarios.
- **Almacenamiento local:** desde la configuración se puede seleccionar una carpeta personalizada para los respaldos cuando el navegador ofrece `showDirectoryPicker()`. El acceso a la carpeta se conserva mediante IndexedDB para poder reutilizarlo posteriormente.
- **Compatibilidad:** si el navegador no permite seleccionar una carpeta local o no existe un permiso válido, NexoCampo utiliza **Descargas** como destino alternativo. Una PWA web no puede garantizar una ruta arbitraria del almacenamiento Android.
- **Respaldo manual:** la creación del respaldo intenta guardar primero en la carpeta local configurada y utiliza Descargas como fallback cuando no es posible acceder a la carpeta personalizada.


## 📌 Cierre técnico — Google Drive

La sincronización con Google Drive queda integrada en `main` y validada en el despliegue de Cloudflare Pages. La ruta visible de respaldos es `NexoCampo/Respaldos/Global`. La subida multipart utiliza CRLF reales y el Service Worker actual es `v11` para evitar servir la versión anterior desde caché.

### Punto de recuperación
El estado previo al ensayo de corrección quedó preservado en la rama `checkpoint/main-safe-2026-09-23`. Los cambios posteriores están registrados en Git y pueden revertirse sin reconstruir NexoCampo.

### Estado del ciclo
- OAuth Google Drive: verificado.
- Creación/visualización de carpetas: verificada.
- Sincronización de respaldo: verificada por prueba real en Cloudflare Pages.
- Cambios fuera del módulo Drive: no realizados durante este cierre.
- Netlify: fuera del flujo de despliegue actual.
