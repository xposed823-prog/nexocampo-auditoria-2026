const { JSDOM } = require("jsdom");
const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const dom = new JSDOM(html, { runScripts: "dangerously", resources: "usable" });
dom.window.addEventListener('error', (e) => { console.log('RUNTIME ERROR:', e.error); });
setTimeout(() => {
  try {
    dom.window.abrirRegistroIndividual();
    console.log('abrirRegistroIndividual ran without throwing errors.');
  } catch(e) {
    console.log('ERROR ON CLICK:', e);
  }
}, 1000);
