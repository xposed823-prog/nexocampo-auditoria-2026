# NexoCampo — Arquitectura de referencia

## Fuente de verdad
Repositorio oficial: `xposed823-prog/nexocampo-pwa-`
Rama principal: `main`
Rama principal operativa: `main`

## Estado conocido de la aplicación
- Entrada operativa: `index.html`.
- PWA mediante `public/manifest.json` y `public/sw.js`.
- IndexedDB activa.
- DB_NAME: `nexocampo`.
- DB_VERSION: `4`.
- Stores: `colaboradores`, `labores`, `areas`, `ausencias`, `jornadas`, `asistencia`.
- Service Worker con caché gestionada desde `public/sw.js`.
- Google Identity Services se carga desde el cliente web de Google.
- Configuración OAuth pública para el despliegue estático: `/google-drive-config.js`.

## Componentes funcionales protegidos
- Registro de jornadas individuales y grupales.
- Seguimiento de labores, metas y rendimientos.
- Asistencia con consulta rápida por colaborador y semana, más detalle de asistencia.
- Consulta cruzada de colaborador por fecha: asistencia, jornada/rendimiento y ausencia formal.
- Gestión de ausencias mediante los códigos: I (Incapacidad), JV (Jurado de Votación), LP (Licencia de Paternidad), P (Permiso), V (Vacaciones), SP (Suspensión) y C (Compensado).
- Ausencias y asistencia son módulos funcionalmente separados: Ausencias formaliza la causa/periodo; Asistencia registra lo ocurrido realmente.
- Informes PDF individual y general.
- Respaldo y restauración.
- Organización de archivos locales autorizados: `NexoCampo/Respaldos`, `NexoCampo/Rendimientos/Grupales`, `NexoCampo/Rendimientos/Individuales`, `NexoCampo/Rendimientos/CSV`, `NexoCampo/Asistencia`, `NexoCampo/Ausencia` y `NexoCampo/Otros`.
- La exportación existente `Rendimientos → Exportar CSV` se guarda automáticamente en `NexoCampo/Rendimientos/CSV` cuando existe una carpeta local autorizada; si no está disponible, conserva Descargas como fallback.
- Los reportes de `Asistencia` y `Ausencia` pueden exportarse en CSV desde sus respectivos módulos. El CSV de asistencia se guarda en `NexoCampo/Asistencia` y el de ausencias en `NexoCampo/Ausencia` cuando existe una carpeta local autorizada; si no está disponible, conservan Descargas como fallback.
- Los reportes PDF de `Asistencia` y `Ausencia` se generan mediante el flujo existente de impresión/“Guardar como PDF” del navegador, por lo que su destino lo controla el navegador/dispositivo.
- Los informes PDF actuales (general e individual) siguen usando el flujo de impresión/“Guardar como PDF” del navegador; la PWA no controla de forma fiable el destino del PDF generado por ese diálogo. Por ello no se fuerza una ruta automática para esos PDF en esta fase.
- Sincronización con Google Drive: implementada y verificada en `main` y desplegada mediante Cloudflare Pages.
- Estrategia de sincronización por dispositivo/cuenta autorizada, con estado local de pendientes y reintento cuando la conectividad lo permita.
- Notificaciones y pendientes.
- Control de almacenamiento.
- Funcionamiento offline/PWA.
- Interfaz responsive orientada a móvil.

## Asistencia y consulta cruzada
- La asistencia es independiente del rendimiento.
- La clave funcional de asistencia es `colaborador_id + fecha`.
- La consulta cruzada es de solo lectura y reutiliza los datos existentes de asistencia, jornadas y ausencias.
- La hora de entrada de asistencia y el inicio laboral de jornada se mantienen como datos separados.
- La consulta no modifica fórmulas ni registros.
- Un permiso (P) puede formalizarse en Ausencias y reflejarse en Asistencia según lo ocurrido realmente, incluyendo situaciones parciales, sin duplicar la causa.

## Sincronización con Google Drive — punto 5
- IndexedDB continúa siendo la fuente de verdad operativa local.
- El respaldo JSON existente se reutiliza como artefacto de copia en Drive.
- La integración usa Google Identity Services y el alcance `https://www.googleapis.com/auth/drive.file`.
- Los respaldos se guardan en una jerarquía visible de My Drive: `NexoCampo/Respaldos/Global`.
- La asociación de estado de Drive es local a cada instalación/dispositivo mediante metadatos locales.
- El token de acceso se mantiene únicamente en memoria; no se guarda un refresh token ni el access token en localStorage.
- La sincronización puede ejecutarse manualmente y se programa/reintenta al recuperar conectividad o al volver a la aplicación.
- No se promete ejecución periódica garantizada con la PWA completamente cerrada: el navegador/Android controla las ventanas de ejecución en segundo plano.
- No se incorpora backend en esta fase.
- No se sobrescriben datos locales silenciosamente ni se realiza una combinación automática destructiva; restaurar/importar sigue siendo una acción explícita.
- La organización visible `NexoCampo/Respaldos/Global` forma parte de la implementación actual.
- Corrección crítica aplicada: el cuerpo multipart de subida utiliza saltos de línea CRLF reales (`\r\n`), y el Service Worker se incrementó a `v11` para invalidar la caché anterior.
- Prueba real verificada: OAuth autorizado, acceso a la jerarquía de carpetas y sincronización de respaldo JSON funcionando en el despliegue de Cloudflare Pages.

## Regla de arquitectura
No sustituir componentes existentes ni reconstruir la aplicación si una evolución localizada puede resolver el objetivo. Antes de cambios estructurales se debe realizar análisis de impacto y compatibilidad.

## Principio de datos
Los datos locales existentes tienen prioridad. Cualquier cambio de persistencia debe proteger la compatibilidad y evitar pérdida de información.

## Nota
Este documento refleja el estado verificado en la rama evolutiva indicada. Debe actualizarse cuando cambie la arquitectura real del repositorio.
