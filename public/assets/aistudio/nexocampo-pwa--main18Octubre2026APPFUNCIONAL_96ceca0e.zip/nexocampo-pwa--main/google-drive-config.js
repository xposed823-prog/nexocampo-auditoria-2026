/* NexoCampo — configuración Google Drive
 * Archivo raíz para el despliegue estático de Cloudflare Pages.
 * El Client ID OAuth de una aplicación web es público; no guardar secretos aquí.
 */
window.NEXOCAMPO_GOOGLE_DRIVE_CONFIG = Object.freeze({
  clientId: '183338576054-6gsdp3t29rqofj87f7m1ep6oit9rsk43.apps.googleusercontent.com'
});
