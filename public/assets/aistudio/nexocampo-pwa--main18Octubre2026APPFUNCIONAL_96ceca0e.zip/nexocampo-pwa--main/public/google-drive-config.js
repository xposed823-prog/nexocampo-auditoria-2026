/* NexoCampo — configuración Google Drive
 * El Client ID es público en una app web. No guardar secretos aquí.
 * Completar clientId con el OAuth 2.0 Client ID de tipo Aplicación web.
 */
window.NEXOCAMPO_GOOGLE_DRIVE_CONFIG = Object.freeze({
  clientId: '183338576054-6gsdp3t29rqofj87f7m1ep6oit9rsk43.apps.googleusercontent.com'
});
