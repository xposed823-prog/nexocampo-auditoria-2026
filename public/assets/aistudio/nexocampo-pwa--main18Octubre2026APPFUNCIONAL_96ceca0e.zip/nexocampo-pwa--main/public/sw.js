const CACHE_NAME = 'nexocampo-v14';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/seedling-192.png',
  '/seedling-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) return caches.delete(key);
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const request = e.request;
  const isDocument = request.mode === 'navigate' || request.destination === 'document' || new URL(request.url).pathname === '/index.html';

  if (isDocument) {
    e.respondWith(
      fetch(request).then((response) => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy)).catch(() => {});
        }
        return response;
      }).catch(() => caches.match(request, { ignoreSearch: true }))
    );
    return;
  }

  e.respondWith(
    caches.match(request, { ignoreSearch: true }).then((response) => {
      return response || fetch(request);
    })
  );
});

// Background Sync para registros de campo pendientes
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-jornadas') {
    event.waitUntil(
      self.registration.showNotification('NexoCampo', {
        body: 'Sincronización en segundo plano completada con éxito.',
        icon: '/seedling-192.png',
        badge: '/seedling-192.png'
      }).catch((err) => {
        console.log('Notificación de sync omitida o no permitida:', err);
      })
    );
  }
});
