const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', error => console.log('PAGE ERROR:', error.message));

  await page.goto('http://localhost:3000');
  
  await new Promise(r => setTimeout(r, 2000));
  console.log("Clicking Individual button using page.click...");
  
  // Find the button with text "Individual"
  const buttonSelectors = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('button')).map((b, i) => {
      b.id = 'btn-' + i;
      return { id: b.id, text: b.innerText };
    });
  });
  console.log(buttonSelectors);
  
  const targetBtn = buttonSelectors.find(b => b.text.includes('Individual'));
  if (targetBtn) {
    await page.click('#' + targetBtn.id);
  } else {
    console.log("Button not found");
  }
  
  await new Promise(r => setTimeout(r, 2000));
  await browser.close();
  console.log("Done");
})();
