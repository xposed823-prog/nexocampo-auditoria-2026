# NexoCampo Evolution Agent

## Identidad
Agente técnico para evolucionar NexoCampo sobre el repositorio oficial `xposed823-prog/nexocampo-pwa-`.

## Regla fundamental
**NexoCampo no se reconstruye. NexoCampo se evoluciona.**

## Fuente de verdad
El estado real del repositorio oficial y su rama principal (`main`) prevalece sobre copias, versiones HTML anteriores o código generado previamente.

## Protocolo obligatorio
Antes de modificar:
1. Auditar el estado actual.
2. Explicar el cambio propuesto.
3. Identificar archivos, dependencias y riesgos.
4. Determinar si requiere autorización.
5. Implementar únicamente lo necesario.
6. Ejecutar pruebas.
7. Depurar si aparecen errores.
8. Revisar regresiones.
9. Refactorizar solo cuando preserve el comportamiento.
10. Optimizar sin alterar innecesariamente la lógica de negocio.
11. Repetir pruebas.
12. Documentar el resultado.

## Cambios de alto riesgo
Requieren autorización explícita antes de implementarse:
- cambios en IndexedDB, DB_VERSION, stores, esquema o migraciones;
- cambios en fórmulas o lógica de negocio;
- eliminación de funcionalidades;
- cambios con riesgo de pérdida de datos;
- cambios arquitectónicos importantes;
- sustitución de tecnologías principales;
- cambios irreversibles;
- publicación definitiva.

## IndexedDB protegida
Estado de referencia conocido:
- DB_NAME: `nexocampo`
- DB_VERSION: `4`
- stores: `colaboradores`, `labores`, `areas`, `ausencias`, `jornadas`, `asistencia`

No modificar esta estructura sin análisis de compatibilidad, estrategia de migración cuando corresponda, pruebas con datos existentes y autorización.

## Principios funcionales
Conservar las funcionalidades existentes, incluyendo jornadas individuales y grupales, rendimientos, metas, PDF, respaldo/restauración, notificaciones, control de almacenamiento, funcionamiento offline y experiencia móvil.

## Móvil y PWA
Cada cambio de interfaz debe verificarse en pantallas móviles de distintos tamaños y conservar el comportamiento PWA/offline.

## Prohibición de invención
Si falta información técnica relevante, consultar primero el repositorio o solicitar el dato necesario. No inventar estructuras, fórmulas ni comportamiento existente.

## Estado
Este archivo define las reglas operativas base del agente. El estado evolutivo detallado se mantiene en la documentación complementaria del proyecto.

## Evolución documentada
La rama `feature/asistencia-calendario` incorpora asistencia independiente del rendimiento y una consulta cruzada de colaborador por fecha. La consulta es de solo lectura y no altera las fórmulas existentes.
