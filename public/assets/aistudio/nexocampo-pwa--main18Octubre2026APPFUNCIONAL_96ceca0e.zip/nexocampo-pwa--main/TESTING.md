# NexoCampo — Estrategia de pruebas

## Objetivo
Detectar errores y regresiones sin alterar las reglas de negocio ni los datos existentes.

## Capas de prueba

### 1. Funcional
Verificar la función modificada y sus rutas relacionadas.

### 2. Regresión
Comprobar que las funciones existentes continúan operativas.

### 3. Persistencia
Verificar IndexedDB, incluyendo lectura/escritura y compatibilidad con datos existentes cuando corresponda.

### 4. PWA/offline
Verificar manifest, Service Worker, caché y funcionamiento sin conexión cuando el cambio los afecte.

### 5. Responsive/móvil
Comprobar tamaños de pantalla móviles, navegación táctil, contenido sin desbordamiento y elementos fijos/flotantes.

## Flujo
`test → debug → review → refactor si aplica → optimize si aplica → test final`

## Regla
Una prueba exitosa de una función aislada no sustituye una prueba de regresión cuando el cambio pueda afectar otras funciones.

## Evidencia
Cada evolución importante debe registrar qué se probó y el resultado en `CHANGELOG.md`.
