## 2026-10-07 — Oficios Varios: catálogo, registro y separación matemática

- Se incorporó **Oficios Varios** como tipo explícito de registro dentro del catálogo existente de `labores`; no se creó un nuevo store de IndexedDB ni se cambió `DB_VERSION`.
- Se agregaron al catálogo, cuando no existían, las tres tareas iniciales: **Limpieza de laterales**, **Recolección y retiro de residuos** y **Correcciones y adecuaciones menores**.
- Oficios Varios se mide exclusivamente mediante **tareas asignadas / tareas completadas** y su porcentaje de cumplimiento operativo; no utiliza minutos estándar, unidades técnicas ni genera rendimiento técnico.
- El registro de jornada conserva `labor_id`, `labor_nombre` y `labor_config_snapshot`, además del marcador `tipo_registro:'oficio_vario'`, para mantener trazabilidad histórica.
- Se incorporó el flujo de crear/editar/desactivar Oficios Varios mediante el catálogo existente; la desactivación conserva los registros históricos.
- En la jornada se añadieron los campos de tareas asignadas/completadas, ubicación, estado y nota opcional.
- Pendiente se determina por avance incompleto y queda fuera del promedio de rendimiento técnico; una labor cerrada como Cumple queda como cumplimiento operativo independiente.
- El motor `calcularRendimientoTramo()` y `calcularRendimientoJornada()` excluye explícitamente Oficios Varios del rendimiento técnico.
- Consulta Cruzada, detalle de jornada y PDF individual muestran Oficios Varios por separado, sin mezclar su porcentaje operativo con el rendimiento técnico.
- No se modificaron Google Drive, PWA, Service Worker, asistencia ni las fórmulas técnicas de las labores estandarizadas.
- Implementación funcional: `eadbaafd97f0118842772cefc9148fb233299d1d`, integración de consultas/reportes: `e8781366d84bbfbb77b104a6af8348c12c1db34c`.
- Verificación estructural pendiente de aceptación funcional móvil; no se afirma prueba de navegador real desde este entorno.

## 2026-10-05 — Cierre matemático de estados de labor (Punto 3)

- Se formaliza el comportamiento matemático de los seis estados: **Planificada, Pendiente, Cumple, Validado, Rechazado por calidad y No cumple**.
- **Planificada** y **Pendiente** no generan producción válida ni entran al rendimiento mientras estén abiertos.
- **Cumple** y **Validado** generan la misma producción; Validado representa confirmación de supervisión y no duplica rendimiento.
- **No cumple** y **Rechazado por calidad** cierran la labor con producción aceptada de cero; las unidades registradas no se convierten en minutos estándar válidos.
- Una jornada con labor estándar cerrada en No cumple/Rechazado puede producir **0%**, en lugar de quedar como rendimiento nulo, mientras que jornadas sin labor estándar evaluable continúan sin rendimiento calculable.
- Se corrigió la inconsistencia previa de `_minutosEstandarGanados()`, que podía convertir unidades registradas en producción válida aunque la labor estuviera en No cumple/Rechazado por calidad.
- `calcularRendimientoTramo()` ahora devuelve `0` para esos estados cerrados y mantiene `null` para Planificada/Pendiente.
- `_jornadaTienePendientes()` se conserva como mecanismo de exclusión de jornadas abiertas.
- No se añadieron campos, stores ni estándares nuevos. No se modificaron Consulta Cruzada, visores del punto 2, IndexedDB, Google Drive ni PWA/service worker.
- **Implementación:** `9f82a753198f6fcb828838bb9965e30d9dba2b13`.
- **Prueba estructural:** PASS. Se verificó el código publicado en `main` y la ausencia de la fórmula anterior que solo generaba rendimiento global cuando `minEstandar > 0`.
- **Pendiente:** prueba funcional en el celular con casos Planificada, Pendiente, Cumple, Validado, No cumple, Rechazado por calidad y meta grupal. El caso de rechazo parcial sigue sin inventarse porque el modelo actual no posee `unidades_rechazadas`.

# NexoCampo — Changelog
## 2026-10-05 — Punto 2: visores de Jornadas y Rendimientos
- Se implementaron dos accesos visuales en Reportes: **Jornadas** y **Rendimientos**.
- **Jornadas** abre un panel de solo lectura con lista general desplazable, fecha, colaboradores, tipo, inicio/fin reconstruidos desde los tramos, cantidad de labores, minutos productivos y rendimiento cuando corresponde.
- **Rendimientos** abre un panel de solo lectura con promedio general y resumen por colaborador; las jornadas con pendientes se excluyen del promedio.
- Los nuevos visores reutilizan `enriquecerTramo()`, `calcularRendimientoJornada()` y `_jornadaTienePendientes()`; no crean stores, campos ni fórmulas nuevas.
- Se mantiene **Consulta Cruzada** como mecanismo de consulta detallada por colaborador y fecha.
- No se modificaron la fórmula de rendimiento, IndexedDB, registro/edición de jornadas, Google Drive, PWA ni Service Worker.
- Implementación: `c58c4d1ab058c62fb6f5b876a2d6687e65ba1b1e`.
- Prueba estructural: PASS; funciones, tarjetas y contenido de solo lectura presentes en `main`. Prueba funcional en dispositivo pendiente de aceptación visual.
- Nota de alcance: el detalle existente de una jornada conserva sus acciones administrativas de editar/borrar; los nuevos visores generales son exclusivamente de lectura.


## 2026-10-05

### Consulta Cruzada — corrección de jornada y rendimiento
- Se corrigió de forma localizada `abrirConsultaColaborador()` en `index.html`.
- La consulta ahora reconstruye el inicio y fin laboral a partir de los tramos persistidos de la jornada, en lugar de depender de campos de jornada que no se almacenan como fuente principal.
- Se muestran las labores/tramos asociados con su estado, horario, ubicación y resultado cuando corresponde.
- El rendimiento técnico de la jornada se obtiene mediante `calcularRendimientoJornada()`, manteniendo la misma lógica central utilizada por Reportes.
- Las jornadas con pendientes se identifican mediante `_jornadaTienePendientes()` y no se presentan como rendimiento técnico válido cerrado.
- Se conserva la consulta de asistencia y ausencia formal sin alterar sus registros ni sus reglas.
- No se modificaron IndexedDB, fórmulas globales, Reportes, Registro, Asistencia, Ausencias, Google Drive, PWA, Service Worker, manifest ni otros componentes.
- Commit de implementación: `e8cadef096e0e0596be49de82bd0c5c6ba42db06` — `fix: corregir consulta cruzada de jornada y rendimiento`.
- Estado de implementación: **PASS estructural**.
- Pendiente de esta etapa: prueba funcional con una jornada real en la aplicación para cerrar la validación de aceptación.
- Nota de alcance: la posible doble contabilización de minutos por tramos solapados detectada durante el red-team pertenece a la matemática global de rendimiento y **no fue modificada** en esta corrección.

## 2026-09-20

### Ausencias — actualización de códigos
- Se reemplazó el catálogo anterior por I (Incapacidad), JV (Jurado de Votación), LP (Licencia de Paternidad), P (Permiso), V (Vacaciones), SP (Suspensión) y C (Compensado).
- Se conserva la pantalla independiente de Ausencias y la separación funcional con Asistencia.
- El código P puede formalizarse en Ausencias y reflejarse en Asistencia según lo ocurrido realmente, sin duplicar la causa.
- Verificaciones de test, debug, review, refactor, optimize y responsive móvil: PASS.
- Secuencia completada: /audit → /explain → /code → /test → /debug → /review → /refactor → /optimize → /test → /responsive-movil → /documentation.

### Asistencia — consulta cruzada y ajuste responsive
- Se documenta la incorporación del módulo de asistencia con persistencia en el store `asistencia`.
- Se incorpora la consulta cruzada de colaborador por fecha, mostrando asistencia, jornada/rendimiento y ausencia formal en una pantalla de consulta.
- Se mantiene la separación entre hora de entrada de asistencia e inicio laboral de jornada.
- Se ajusta de forma localizada el campo de fecha de consulta para evitar desbordamiento visual en móvil.
- Se verifica la adaptación responsive de la consulta.
- Secuencia ejecutada: `/audit → /explain → /code → /test → /debug → /review → /refactor → /optimize → /test → /responsive-movil → /documentation`.
- Resultado final de las verificaciones: **PASS**.
- La documentación se actualiza sin modificar la lógica de negocio durante esta etapa.

## 2026-09-19

### Evolución responsive móvil — revisión exhaustiva
- Se realizó una revisión estática exhaustiva de `index.html` sobre `main`.
- Se verificaron los breakpoints para pantallas de hasta 360 px y de 361–480 px.
- Se verificó la orientación horizontal en pantallas de poca altura.
- Se verificaron navegación inferior fija, botón de notificaciones, safe-area, formularios táctiles y prevención de desbordamiento horizontal.
- Se verificó el comportamiento responsive de tarjetas, grillas, modales, imágenes y contenidos largos.
- Resultado: **PASS**.
- No se requirieron cambios de código.

## 2026-09-17

### Evolution Agent — documentación inicial
- Se incorporó `AGENTS.md` con las reglas operativas del NexoCampo Evolution Agent.
- Se incorporó `ARCHITECTURE.md` con la arquitectura y funcionalidades protegidas conocidas.
- Se incorporó `TESTING.md` con la estrategia de pruebas.
- Se incorporó `ROADMAP.md` con las prioridades evolutivas iniciales.

### Protección
- No se modificó `index.html`.
- No se modificó IndexedDB.
- No se modificaron fórmulas ni lógica de negocio.
- No se eliminaron funcionalidades existentes.
- No se modificó el Service Worker.
- No se modificó el manifest.

### Estado
Documentación base creada para permitir continuidad técnica del proyecto.
