# NexoCampo — Roadmap evolutivo

## Estado actual
La documentación base del NexoCampo Evolution Agent ha sido incorporada al repositorio sin modificar la aplicación ni su estructura de datos.

## Prioridades
1. Mantener la estabilidad de las funcionalidades existentes.
2. Consolidar el protocolo de análisis, desarrollo y pruebas.
3. Mejorar progresivamente la documentación técnica.
4. Verificar responsive/PWA después de cada evolución relevante.
5. Evaluar mejoras funcionales únicamente sobre necesidades reales del campo.

## Pendientes de análisis
- Integración operativa completa del flujo de desarrollo asistido con GitHub/Codex.
- Auditoría específica del flujo GitHub → publicación/Netlify antes de modificarlo.
- Revisión continua de Service Worker y estrategia de caché.
- Pruebas móviles sobre diferentes tamaños de pantalla.

## Regla
No convertir un elemento del roadmap en cambio de código sin análisis previo y autorización cuando corresponda.
