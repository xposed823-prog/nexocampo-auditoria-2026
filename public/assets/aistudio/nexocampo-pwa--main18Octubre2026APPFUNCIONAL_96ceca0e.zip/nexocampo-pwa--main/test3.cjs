const { JSDOM } = require("jsdom");
const fs = require('fs');
const indexedDB = require("fake-indexeddb");
const IDBKeyRange = require("fake-indexeddb/lib/FDBKeyRange");

const html = fs.readFileSync('index.html', 'utf8');
const dom = new JSDOM(html, {
  runScripts: "dangerously", 
  resources: "usable",
  beforeParse(window) {
    window.indexedDB = indexedDB;
    window.IDBKeyRange = IDBKeyRange;
    window.onerror = function(msg, url, line, col, error) {
      console.log("ONERROR:", msg, line, col, error);
    };
  }
});
setTimeout(() => {
  console.log("Running seed...");
  dom.window.seed().then(async () => {
    console.log("Seed done. Calling render...");
    dom.window.render();
    console.log("Render done. Calling abrirRegistroIndividual...");
    try {
      dom.window.abrirRegistroIndividual();
      console.log('abrirRegistroIndividual finished without throw.');
    } catch(e) {
      console.log('CATCH BLOCK:', e);
    }
  }).catch(e => console.log('SEED CATCH:', e));
}, 1000);
