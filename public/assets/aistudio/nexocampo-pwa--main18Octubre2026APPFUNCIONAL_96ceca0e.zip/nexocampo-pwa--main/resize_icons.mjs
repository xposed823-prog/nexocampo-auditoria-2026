import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function resizeImage(filename, size) {
  const filepath = path.join(__dirname, 'public', filename);

  if (!fs.existsSync(filepath)) {
    console.warn(`⚠️ Advertencia: El archivo '${filepath}' no se encontró. Asegúrate de haber subido la imagen a la carpeta 'public/'.`);
    return;
  }

  try {
    const buffer = await fs.promises.readFile(filepath);
    
    await sharp(buffer)
      .resize(size, size, {
        fit: 'contain',
        background: { r: 0, g: 0, b: 0, alpha: 0 } // Fondo transparente
      })
      .toFormat('png')
      .toFile(filepath);

    console.log(`✅ Éxito: '${filename}' redimensionada correctamente a ${size}x${size} píxeles.`);
  } catch (error) {
    console.error(`❌ Error al procesar '${filename}':`, error.message);
  }
}

async function main() {
  console.log("Iniciando optimización de iconos de la PWA...");
  
  // Redimensionar seedling (1).png a 192x192
  await resizeImage('seedling (1).png', 192);
  
  // Redimensionar seedling (2).png a 512x512
  await resizeImage('seedling (2).png', 512);
  
  console.log("Proceso finalizado.");
}

main();
